package pojo;

public class Validator {
}
