package pojo;

public class Executor {

    private String eventId;
    private String tableName;
    private String explanationCode;
    private String statusCode;
    private String statusMessage;
    private String placement1DefaultRef;
    private String placement1ExperienceType;
    private String value;
    private String market;
    private String GCTID;
    private String languageCode;

    public Executor(){}

/*    public Executor(String description) {

        final String descriptionPath="src/main/java/resources/executorInput.json";
        Executor executor = (Executor) TestDataManager.getInstance(Executor.class, descriptionPath);

        this.eventId = eventId;
        this.tableName = tableName;
        this.explanationCode = explanationCode;
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
        this.placement1DefaultRef = placement1DefaultRef;
        this.placement1ExperienceType = placement1ExperienceType;
        this.value = value;
        this.market = market;
        this.GCTID = GCTID;
        this.languageCode = languageCode;
    }*/

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getExplanationCode() {
        return explanationCode;
    }

    public void setExplanationCode(String explanationCode) {
        this.explanationCode = explanationCode;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getPlacement1DefaultRef() {
        return placement1DefaultRef;
    }

    public void setPlacement1DefaultRef(String placement1DefaultRef) {
        this.placement1DefaultRef = placement1DefaultRef;
    }

    public String getPlacement1ExperienceType() {
        return placement1ExperienceType;
    }

    public void setPlacement1ExperienceType(String placement1ExperienceType) {
        this.placement1ExperienceType = placement1ExperienceType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getGCTID() {
        return GCTID;
    }

    public void setGCTID(String GCTID) {
        this.GCTID = GCTID;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
}
