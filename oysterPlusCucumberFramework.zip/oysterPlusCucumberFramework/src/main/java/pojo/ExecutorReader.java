package pojo;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import com.google.gson.Gson;
import dataProviders.FileReaderManager;
import pojo.Executor;

public class ExecutorReader {
    private final String customerFilePath = "src\\main\\java\\resources\\executorInput.json";
    private List<Executor> customerList;

    public ExecutorReader(){
        customerList = getCustomerData();
    }

    private List<Executor> getCustomerData() {
        Gson gson = new Gson();
        BufferedReader bufferReader = null;
        try {
            bufferReader = new BufferedReader(new FileReader(customerFilePath));
            Executor[] customers = gson.fromJson(bufferReader, Executor[].class);
            return Arrays.asList(customers);
        }catch(FileNotFoundException e) {
            throw new RuntimeException("Json file not found at path : " + customerFilePath);
        }finally {
            try { if(bufferReader != null) bufferReader.close();}
            catch (IOException ignore) {}
        }
    }

    public final Executor getByEventDetails(String customerName){
        return customerList.stream().filter(x -> x.getEventId().equalsIgnoreCase(customerName)).findAny().get();
    }
}