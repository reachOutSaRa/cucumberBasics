package dataProviders;

import pojo.ExecutorReader;

public class FileReaderManager {

    private static FileReaderManager fileReaderManager = new FileReaderManager();
    private static ConfigFileReader configFileReader;
    private static ExecutorReader executorReader;

    private FileReaderManager() {
    }

    public static FileReaderManager getInstance( ) {
        return fileReaderManager;
    }

    public ConfigFileReader getConfigReader() {
        return (configFileReader == null) ? new ConfigFileReader() : configFileReader;
    }

    public ExecutorReader getJsonReader(){
        return (executorReader == null) ? new ExecutorReader() : executorReader;
    }
}