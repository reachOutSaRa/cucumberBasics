package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StraightForwardDefinition {

    @Given("^Offer_Applicable is set to No in Master_Market Table$")
    public void offerApplicable()   {
        
        System.out.println("Straight Forward execution \nOffer Applicable is set\n");
        
    
    }

    @And("^Control is set to 100 in L1_Randomization table$")
    public void control()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Control is set \n");
        //
    
    }

    @And("^Test is set to 0 in L1_Randomization table$")
    public void test()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Test is set \n");
        
    
    }

    @And("^Training is set to 0 in L1_Randomization table$")
    public void training()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Training is set \n");

    
    }

    @And("^Banner Model is uploaded to MAB model tables$")
    public void banner()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Banner is set \n");


    }

    @When("^PZN request is fired for PZN1$")
    public void PZN()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("PZN request is fired \n API is called" );
    
    }

    @Then("^currentexperiencetype should be Control in oplus_rr table$")
    public void currentExperienceType()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Current Experience Type is Control \n");
        
    
    }

    @And("^Placement1DefaultRef should be Bkgd85 in oplus_rr table$")
    public void placementDefaultRef()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Placement DefaultRef is BKGD85 \n");
        
    
    }

    @And("^finalmodeloutput_p2 should be BKGD85 in gbdt_info table$")
    public void finalModelOutput()   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Final Model Output had BKGD in GBDT \n\n");
        
    
    }
}
