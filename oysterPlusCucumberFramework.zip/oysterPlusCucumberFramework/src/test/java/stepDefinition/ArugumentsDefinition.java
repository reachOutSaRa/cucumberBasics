package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ArugumentsDefinition {

    @Given("^Offer_Applicable is set to \"([^\"]*)\" in Master_Market Table$")
    public void offer_applicable_is_set_to_in_Master_Market_Table(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Parameterized execution \nOffer Applicable is set to " + arg1 + "\n");
        
    }

    @Given("^Control is set to \"([^\"]*)\" in L1_Randomization table$")
    public void control_is_set_to_in_L__Randomization_table(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Control is set to " + arg1 +" in L1_Randomization table"+ "\n");
        
    }

    @Given("^Test is set to \"([^\"]*)\" in L1_Randomization table$")
    public void test_is_set_to_in_L__Randomization_table(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Test is set to " + arg1 +" in L1_Randomization table"+ "\n");
        
    }

    @Given("^Training is set to \"([^\"]*)\" in L1_Randomization table$")
    public void training_is_set_to_in_L__Randomization_table(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Training is set to " + arg1 +" in L1_Randomization table"+ "\n");
        
    }

    @And("^Banner Model is \"([^\"]*)\" to MAB model tables$")
    public void banner(String arg1)   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("Banner is "+ arg1 +"\n");


    }

    @Then("^Current Experience Type should be \"([^\"]*)\" in oplus_rr table$")
    public void currentExperienceType(String arg1)   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("CurrentExperienceType is " + arg1 +" in L1_Randomization table"+ "\n");

        
    }

    @Then("^Placement1DefaultRef should be \"([^\"]*)\" in oplus_rr table$")
    public void placement_DefaultRef_should_be_BKGD_in_oplus_rr_table(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("PlacementDefaultRef is " + arg1 +" in L1_Randomization table"+ "\n");
        
    }

    @Then("^finalmodeloutput_p2 should be \"([^\"]*)\" in \"([^\"]*)\" table$")
    public void finalmodeloutput_p_should_be_BKGD_in_gbdt_info_table(String arg1, String arg2)  {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("FinalModelOutput is " + arg1 +" in "+ arg2 +" table \n\n");
        
    }
}
