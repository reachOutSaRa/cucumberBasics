package stepDefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dataProviders.FileReaderManager;
import pojo.Executor;

public class JSONInput {

    @When("^PZN request is fired for \"([^\"]*)\"$")
    public void PZN(String arg1)   {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("PZN request is fired for" + arg1 +"\nAPI is called\n" );

/*        Executor executor = FileReaderManager.getInstance().getJsonReader().getByEventDetails(arg1);
        System.out.println(executor.getGCTID());
        System.out.println(executor.getStatusCode());*/
    }
}
